import json, re, time
from pathlib import Path
import requests
from config import OLLAMA_URL, MODEL, TIMEOUT, ART


def ask(stage, system, prompt, json_mode=False, tokens=450):
    request = {'model': MODEL, 'stream': False, 'messages': [
        {'role':'system','content':system}, {'role':'user','content':prompt}],
        'options': {'temperature':0, 'num_predict':tokens}}
    if json_mode:
        request['format'] = 'json'
    (ART / f'{stage}_request.json').write_text(json.dumps(request,indent=2),encoding='utf8')
    start=time.monotonic()
    try:
        r=requests.post(f'{OLLAMA_URL}/api/chat',json=request,timeout=TIMEOUT)
        r.raise_for_status()
        data=r.json()
        output=data['message']['content']
        (ART / f'{stage}_response.txt').write_text(output,encoding='utf8')
        print(f'  Ollama {stage}: {time.monotonic()-start:.1f}s')
        return output
    except Exception as exc:
        (ART / f'{stage}_error.txt').write_text(repr(exc),encoding='utf8')
        raise RuntimeError(f'Ollama failed at {stage}: {exc}. See artifacts/{stage}_error.txt') from exc


def parse_json(raw):
    try: return json.loads(raw)
    except json.JSONDecodeError:
        match=re.search(r'\{[\s\S]*\}',raw)
        if match: return json.loads(match.group())
        raise


def extract_python(raw):
    match=re.search(r'```(?:python)?\s*([\s\S]*?)```',raw)
    return (match.group(1) if match else raw).strip()+'\n'
