import ast, json
from config import ROOT, URL
from llm import ask, extract_python

def run(plan,snapshot):
    print('2/4 Generator: Ollama writes Python Playwright pytest test')
    prompt=f'''Generate ONE complete Python pytest test file using playwright.sync_api.sync_playwright. Test the following scenario:\n{json.dumps(plan['cases'][0])}\nActual browser accessibility snapshot:\n{snapshot[:6500]}\nWebsite: {URL}\nPublic SauceDemo credentials for demo: standard_user / secret_sauce.\nRequirements: one test function named test_login, headed browser launch headless=False, open page, fill username and password, click login, assert inventory page via URL or visible inventory title, browser.close() in finally. No other imports except pytest and playwright. No screenshots. Return ONLY Python code. Prefer get_by_role or get_by_placeholder based on actual snapshot. Avoid hardcoded sleeps.'''
    code=extract_python(ask('generator','You write minimal executable Python Playwright tests. Return only Python code.',prompt,tokens=750))
    ast.parse(code)
    if 'def test_login' not in code or 'sync_playwright' not in code: raise ValueError('Generated code missing required test structure')
    path=ROOT/'generated_tests'/'test_login.py'
    path.write_text(code,encoding='utf8')
    print('  Saved generated_tests/test_login.py')
    return path
