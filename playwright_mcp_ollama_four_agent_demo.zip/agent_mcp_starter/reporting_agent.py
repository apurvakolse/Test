"""Agent 4: evidence-grounded Ollama narrative plus deterministic HTML/JSON reporting."""
import html
import json
from datetime import datetime, timezone
from pathlib import Path
from config import ART, MODEL
from llm import ask, parse_json


def run(events, overall_status, error=None):
    print('5/5 Reporting: compiling execution evidence and asking Ollama for QA summary')
    # Reporting never determines PASS/FAIL. Execution exit codes are the source of truth.
    compact = [{k: v for k, v in e.items() if k in ('stage','status','detail','file','duration_seconds')} for e in events]
    prompt = (
        'Write a concise QA report based ONLY on the supplied evidence. '
        'Return JSON object with string keys executive_summary, findings, risks, recommendations. '
        'Do not invent test results, do not claim tests passed unless evidence says PASS. '
        'A simulated locator failure is not a product defect. '
        f'EVIDENCE: {json.dumps({"overall_status":overall_status,"events":compact,"error":error}, ensure_ascii=False)[:4500]}'
    )
    ai = None
    ai_error = None
    try:
        raw = ask('reporter', 'You are an evidence-based QA reporting agent. Return JSON only.', prompt, json_mode=True, tokens=380)
        ai = parse_json(raw)
        if not isinstance(ai, dict):
            raise ValueError('Reporting response was not a JSON object')
    except Exception as exc:
        ai_error = str(exc)
        print('  Reporter Ollama unavailable; report will explicitly show AI reporting failure.')
    data = {
        'generated_at_utc': datetime.now(timezone.utc).isoformat(),
        'overall_status': overall_status,
        'ollama_model': MODEL,
        'events': events,
        'error': error,
        'ai_report': ai,
        'ai_report_error': ai_error,
        'notes': ['PASS/FAIL comes from pytest exit codes, not Ollama.',
                  'Self-healing only attempts to repair test automation; a passing repair does not prove an application defect was fixed.']
    }
    (ART/'final_report.json').write_text(json.dumps(data, indent=2, default=str), encoding='utf8')
    rows = ''.join(
        '<tr><td>'+html.escape(str(e.get('stage','')))+'</td><td class="'+('ok' if e.get('status')=='PASS' else 'bad' if e.get('status')=='FAIL' else '')+'">'+html.escape(str(e.get('status','')))+'</td><td>'+html.escape(str(e.get('detail','')))+'</td><td>'+html.escape(str(e.get('file','')))+'</td></tr>'
        for e in events
    )
    ai_text = json.dumps(ai, indent=2, ensure_ascii=False) if ai else 'AI reporting unavailable: '+str(ai_error)
    report = '''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Playwright MCP AI Agent Demo Report</title>
<style>body{font:16px/1.5 system-ui,Arial,sans-serif;max-width:1100px;margin:35px auto;padding:0 20px;color:#1f2937}h1{color:#1d4ed8}table{border-collapse:collapse;width:100%}th,td{padding:12px;border:1px solid #cbd5e1;text-align:left;vertical-align:top}th{background:#e2e8f0}.ok{color:#15803d;font-weight:bold}.bad{color:#b91c1c;font-weight:bold}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f1f5f9;padding:18px;border-radius:8px}small{color:#475569}</style></head><body>
<h1>Playwright MCP + Ollama: QA Agent Report</h1>
<p><strong>Overall workflow:</strong> STATUS_PLACEHOLDER</p>
<p><strong>Generated:</strong> DATE_PLACEHOLDER &nbsp; <strong>Model:</strong> MODEL_PLACEHOLDER</p>
<h2>Agent and execution stages</h2><table><thead><tr><th>Stage</th><th>Status</th><th>Evidence</th><th>Artifact</th></tr></thead><tbody>ROWS_PLACEHOLDER</tbody></table>
<h2>Reporting Agent — Ollama analysis</h2><pre>AI_PLACEHOLDER</pre>
<h2>Execution logs and evidence</h2><p>Inspect <code>artifacts/</code> for MCP snapshots, model requests/responses, original and healed pytest logs, generated tests, and <code>final_report.json</code>.</p>
<p><small>Test outcomes are determined by pytest. An intentionally stale locator is a simulated automation failure, not an application bug. If Ollama reporting fails, this is shown explicitly.</small></p></body></html>'''
    for key, value in {'STATUS_PLACEHOLDER':overall_status,'DATE_PLACEHOLDER':data['generated_at_utc'],'MODEL_PLACEHOLDER':MODEL,'ROWS_PLACEHOLDER':rows,'AI_PLACEHOLDER':html.escape(ai_text)}.items():
        report=report.replace(key,value)
    (ART/'report.html').write_text(report, encoding='utf8')
    print('  Saved artifacts/report.html and artifacts/final_report.json')
    return data
