"""Grounded OHIF length-measurement interactions. Never sends OS media keys."""
import json
import re
from pathlib import Path

from playwright.sync_api import TimeoutError as PlaywrightTimeoutError


def find_length_tool(page, output_dir):
    """Find an actual visible length tool; fail rather than silently fake drawing."""
    candidates = [
        page.get_by_role('button', name=re.compile(r'^(length|distance)( measurement| tool)?$', re.I)),
        page.locator('button[title*="Length" i], button[aria-label*="Length" i], button[title*="Distance" i], button[aria-label*="Distance" i]'),
        page.get_by_text(re.compile(r'^Length$', re.I), exact=True),
    ]
    for loc in candidates:
        for i in range(min(loc.count(), 12)):
            item = loc.nth(i)
            try:
                if item.is_visible():
                    return item
            except Exception:
                pass
    # The tool may live in an overflow menu. Open a clearly labeled menu, then retry.
    menus = page.locator('button[aria-label*="More" i],button[title*="More" i],button[aria-label*="Measurement" i],button[title*="Measurement" i]')
    for i in range(min(menus.count(), 8)):
        try:
            if menus.nth(i).is_visible():
                menus.nth(i).click(timeout=2000)
                for loc in candidates:
                    for j in range(min(loc.count(), 12)):
                        if loc.nth(j).is_visible():
                            return loc.nth(j)
        except Exception:
            continue
    snapshot = page.locator('button,[role="button"],[title],[aria-label]').evaluate_all('''els => els.map(e=>({text:(e.innerText||'').trim().slice(0,60),title:e.getAttribute('title'),aria:e.getAttribute('aria-label')})).slice(0,200)''')
    Path(output_dir, 'measurement_tool_debug.json').write_text(json.dumps(snapshot, indent=2), encoding='utf-8')
    raise RuntimeError('Length measurement tool was not found in the current OHIF toolbar. See measurement_tool_debug.json. No simulated drawing was performed.')


def viewport_box(page):
    canvases = page.locator('canvas')
    boxes = []
    for i in range(canvases.count()):
        box = canvases.nth(i).bounding_box()
        if box and box['width'] >= 250 and box['height'] >= 250:
            boxes.append(box)
    if not boxes:
        raise RuntimeError('No visible image canvas large enough to draw a measurement')
    # Prefer the largest actual image canvas.
    return max(boxes, key=lambda b: b['width'] * b['height'])


def draw_length(page, start, end, output_dir):
    """Use normalized coordinates so browser size/viewport offsets are respected."""
    tool = find_length_tool(page, output_dir)
    tool.click(timeout=5000)
    page.wait_for_timeout(350)
    box = viewport_box(page)
    def point(frac):
        return (box['x'] + box['width'] * frac[0], box['y'] + box['height'] * frac[1])
    sx, sy = point(start)
    ex, ey = point(end)
    page.mouse.move(sx, sy)
    page.mouse.down()
    page.mouse.move(ex, ey, steps=25)
    page.mouse.up()
    page.wait_for_timeout(1300)
    return {'canvas_box': box, 'start': [round(sx, 1), round(sy, 1)], 'end': [round(ex, 1), round(ey, 1)]}
