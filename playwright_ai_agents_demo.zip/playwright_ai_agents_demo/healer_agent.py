from pathlib import Path
from ollama_client import ask
import ast,json
from browser_tools import inspect

def run(original,failed_log,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    evidence=inspect('http://127.0.0.1:8765/?version=v2')
    (out/'dom_v2.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
    original=Path(original)
    prompt=f'You are repairing a failing Playwright Python pytest test after a UI locator change. Fix selectors only, do NOT weaken or remove assertions, do NOT change test data or expected behavior. Ensure page.goto URLs use ?version=v2. Return JSON with keys explanation (string), code (complete corrected Python module). Original source:\n{original.read_text(encoding="utf-8")}\nFailure:\n{failed_log[-6500:]}\nCurrent DOM:\n{json.dumps(evidence)}'
    result=ask('You are a cautious Playwright locator repair agent.',prompt,out/'healer',1700)
    code=result.get('code','')
    if not isinstance(code,str) or not code.strip():raise ValueError('Healer returned no code')
    ast.parse(code)
    (out/'test_login.py').write_text(code,encoding='utf-8')
    (out/'explanation.txt').write_text(str(result.get('explanation','')),encoding='utf-8')
    return out/'test_login.py'
