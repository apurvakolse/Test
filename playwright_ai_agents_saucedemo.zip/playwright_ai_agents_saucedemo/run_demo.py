"""Run: python run_demo.py [--simulate-stale-locator]"""
import argparse,json,subprocess,sys,shutil,re
from pathlib import Path
from docx import Document
from planner_agent import run as plan
from generator_agent import run as generate
from healer_agent import run as heal
ROOT=Path(__file__).resolve().parent
ART=ROOT/'artifacts';ART.mkdir(exist_ok=True)

def execute(path,label):
    cmd=[sys.executable,'-m','pytest','-v','--tb=short',str(path),'--json-report',f'--json-report-file={ART/(label+".json")}']
    try:
        r=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=180)
        log=r.stdout+'\n'+r.stderr
        (ART/(label+'.log')).write_text(log,encoding='utf8')
        print(label,'exit:',r.returncode,'\n',log[-1700:],flush=True)
        return r.returncode,log
    except subprocess.TimeoutExpired as e:
        log='Pytest timed out: '+str(e)
        (ART/(label+'.log')).write_text(log,encoding='utf8')
        return 124,log

def simulate_stale_locator(source):
    # Optional controlled demo failure. Changes a COPY of generated code only.
    # It is never presented as a real application regression.
    text=source.read_text(encoding='utf8')
    substitutions=[
        ('[data-test="login-button"]','[data-test="login-button-removed"]'),
        ("[data-test='login-button']","[data-test='login-button-removed']"),
        ('get_by_role("button", name="Login")','get_by_role("button", name="Old Login")'),
    ]
    for old,new in substitutions:
        if old in text:
            target=ROOT/'artifacts'/'test_stale_locator.py'
            target.write_text(text.replace(old,new),encoding='utf8')
            return target
    raise RuntimeError('Could not safely inject a stale locator into generated code. Review generated-tests/test_saucedemo.py; no fabricated failure.')

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--simulate-stale-locator',action='store_true',help='Deliberately break one locator in a COPY to demonstrate healing')
    args=parser.parse_args()
    req='\n'.join(p.text for p in Document(ROOT/'requirements/requirements.docx').paragraphs if p.text.strip())
    print('1/4 Planner: exploring SauceDemo and writing test plan',flush=True)
    cases,evidence=plan('https://www.saucedemo.com/',req,ART)
    print('2/4 Generator: creating Playwright Python tests',flush=True)
    generated=generate(cases,evidence,ROOT/'generated-tests')
    print('3/4 Running generated tests',flush=True)
    original_status,original_log=execute(generated,'generated_run')
    test_for_healing=generated;status=original_status;failure_log=original_log
    if args.simulate_stale_locator and original_status==0:
        print('OPTIONAL DEMO: Injecting a stale locator in a COPY of the test (not changing SauceDemo)',flush=True)
        test_for_healing=simulate_stale_locator(generated)
        status,failure_log=execute(test_for_healing,'stale_locator_run')
        if status==0:raise RuntimeError('Stale locator test unexpectedly passed; stopping.')
    elif args.simulate_stale_locator and original_status!=0:
        print('Generated tests already failed; healing real failure instead of injecting one.',flush=True)
    healed_status=None
    if status!=0:
        print('4/4 Healer: diagnosing failed test from traceback and current DOM',flush=True)
        healed=heal(test_for_healing,failure_log,ROOT/'healed-tests')
        healed_status,_=execute(healed,'healed_run')
    else:print('4/4 No failure: healer correctly skipped. Run --simulate-stale-locator to demonstrate it.',flush=True)
    summary={'generated_test_passed':original_status==0,'healer_invoked':status!=0,'healed_test_passed':None if healed_status is None else healed_status==0,'simulated_failure':bool(args.simulate_stale_locator and original_status==0)}
    (ART/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    print('SUMMARY',json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':main()
