# DICOM Visual Verification — VS Code Demo

## Quick start (Windows PowerShell)

1. Open this folder in VS Code.
2. Open Terminal → New Terminal.
3. Run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m playwright install chromium
python run_demo.py
```

If `py` is unavailable, use `python -m venv .venv`.

## What the project demonstrates

- Opens the public OHIF Viewer and selects the **CTA Head and Neck** study using the already-proven `get_by_text(..., exact=True).dblclick()` approach.
- Discovers actual DOM controls, browser resolution, and canvas bounding boxes.
- Agent 1 generates three validated *declarative* test definitions (JSON), optionally using remote Ollama.
- Executes three visual checks: baseline capture smoke check, repeated screenshot comparison, and intentionally altered screenshot comparison.
- Agent 2 computes pixel-difference ratios and creates visual diff images.
- Agent 3 writes `results/<timestamp>/report.html`, `report.json`, and supporting evidence.

## Important limitations

- **No preapproved golden image exists.** This demo captures its own baseline at runtime. TC01 is a smoke check, **not independent regression validation**. TC02 checks repeatability against that baseline. TC03 is an **intentional simulated failure**, not a viewer defect.
- The three tests do **not** exercise zoom or pan. Those require app-specific stable selectors and approved expected screenshots.
- The generated JSON is validated against supported operations; this project does not execute arbitrary LLM-generated Python code.
- By default `use_ollama` is `false` because the previously tested remote model was very slow. To demonstrate LLM-generated test naming, set `use_ollama` to `true` in `config.json`. A timeout safely falls back to the built-in plan.
- If OHIF changes its study list, tutorial, or canvas implementation, adjust `run_demo.py` selectors. A visible canvas does not by itself prove that all DICOM pixels are rendered.
- The threshold is a basic per-pixel RGB difference metric, not diagnostic-grade image validation. Dynamic UI regions can cause false differences.

## Configuration

Edit `config.json` to adjust viewer URL, study name, Ollama settings, difference threshold, and intentional failure mode.

## Files

- `run_demo.py`: Playwright launcher, discovery and executor
- `agents.py`: test generation, image comparison, report generation
- `config.json`: settings
- `requirements.txt`: Python dependencies
- `results/`: generated evidence and HTML report

No patient data is uploaded to Ollama by default. If you enable Ollama, the DOM evidence (including UI labels and URL) is sent to the configured remote server. Use only public/de-identified demo data and follow your organization's policies.

## Ollama-enabled edition
All three agent classes now call remote Ollama. Agent 1 proposes test names for three validated actions; Agent 2 interprets pixel comparison metrics (text-only llama3.1 cannot view screenshots); Agent 3 creates a QA assessment from measured results. Each call writes `agent_*_input.json` and `agent_*_output.json` in the run directory. On timeout, the report records the failure rather than falsely claiming AI success. Playwright execution, image threshold verdicts and HTML generation remain deterministic. The model may take 35+ seconds even for a tiny request; this demo can take several minutes and may time out.
