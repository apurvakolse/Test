# SauceDemo — AI Planner / Generator / Self-Healer (Python + Ollama)

Target: https://www.saucedemo.com/ (public demo site). No local HTML site, no screenshots.

## Setup in VS Code PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m playwright install chromium
$env:OLLAMA_URL="http://10.80.101.55:11434"
$env:OLLAMA_MODEL="llama3.1:latest"
$env:OLLAMA_TIMEOUT="240"
python run_demo.py
```

The first run explores the live site, generates a plan, writes Python Playwright tests, runs them and invokes the healer **only if a test fails**.

For a guaranteed *attempt* at demonstrating self-healing without changing the public website, use:

```powershell
python run_demo.py --simulate-stale-locator
```

This option deliberately corrupts a selector in a **copy** of the generated test and runs it. The AI healer receives the actual error and fresh DOM, then proposes repaired code. It is an explicitly simulated automation regression, not a real SauceDemo defect. If the generated code does not contain a known selector, the simulation stops instead of faking evidence.

## Artifacts

- `artifacts/dom_evidence.json`: DOM snapshots before and after login
- `artifacts/test_plan.md`, `artifacts/test_cases.json`: AI-generated plan
- `generated-tests/test_saucedemo.py`: AI-generated original tests
- `artifacts/*.log`, `artifacts/*.json`: actual pytest output
- `healed-tests/test_saucedemo.py`: AI repair (only after a failure)
- `artifacts/planner.*`, `generator.*`, `healer.*`: Ollama requests and responses/errors

## Boundaries

- Uses Python Playwright browser inspection, **not** Playwright MCP; the screenshot's agent roles are reproduced but the underlying browser tool transport differs.
- The generator and healer are truly LLM-driven, not prewritten tests or string-replacement healing.
- Only a demo site's published credentials are used. No private credentials.
- Review AI-generated code before executing outside demo sites. Do not silently weaken assertions or change test expectations.
- Remote Ollama may be slow or return invalid JSON; these failures are logged, not hidden.
- SauceDemo UI may change and external site availability is not controlled by this project.
