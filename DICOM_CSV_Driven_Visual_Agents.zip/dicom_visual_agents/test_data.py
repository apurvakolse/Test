"""Validated CSV test case definitions (no arbitrary code execution)."""
import csv
import re
from pathlib import Path

REQUIRED = {'enabled','id','name','action','baseline_id','baseline_mode','start_x','start_y','end_x','end_y','expected_status'}
ACTIONS = {'capture_baseline', 'draw_measurement'}
MODES = {'create','reuse'}

def load_test_cases(path):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f'Test CSV not found: {path}')
    with path.open(newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        missing = REQUIRED - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f'Missing CSV columns: {sorted(missing)}')
        rows = list(reader)
    tests, ids, available_baselines = [], set(), set()
    for rownum, row in enumerate(rows, start=2):
        if row['enabled'].strip().upper() not in {'Y','YES','TRUE','1'}:
            continue
        test = {k: (row[k] or '').strip() for k in REQUIRED}
        tid, bid = test['id'], test['baseline_id']
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,40}', tid) or tid in ids:
            raise ValueError(f'CSV row {rownum}: invalid or duplicate test id {tid!r}')
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,40}', bid):
            raise ValueError(f'CSV row {rownum}: invalid baseline_id {bid!r}')
        if test['action'] not in ACTIONS or test['baseline_mode'] not in MODES:
            raise ValueError(f'CSV row {rownum}: unsupported action or baseline mode')
        if test['expected_status'] not in {'PASS','FAIL'}:
            raise ValueError(f'CSV row {rownum}: expected_status must be PASS or FAIL')
        if test['baseline_mode'] == 'reuse' and bid not in available_baselines:
            raise ValueError(f'CSV row {rownum}: baseline {bid!r} must be created by an earlier enabled row')
        if test['action'] == 'capture_baseline' and test['baseline_mode'] != 'create':
            raise ValueError(f'CSV row {rownum}: capture_baseline requires create mode')
        if test['action'] == 'draw_measurement':
            try:
                start = [float(test['start_x']),float(test['start_y'])]
                end = [float(test['end_x']),float(test['end_y'])]
            except ValueError as exc:
                raise ValueError(f'CSV row {rownum}: invalid measurement coordinates') from exc
            if any(not 0.05 <= v <= 0.95 for v in start + end) or start == end:
                raise ValueError(f'CSV row {rownum}: coordinates must be 0.05–0.95 and endpoints distinct')
            test['start'], test['end'] = start, end
        ids.add(tid)
        if test['baseline_mode'] == 'create':
            available_baselines.add(bid)
        tests.append(test)
    if not tests:
        raise ValueError('No enabled tests in CSV')
    return tests
