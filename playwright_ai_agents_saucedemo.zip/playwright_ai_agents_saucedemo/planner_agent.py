import json
from pathlib import Path
from ollama_client import ask
from browser_tools import inspect

def run(url, requirements, output):
    output=Path(output);output.mkdir(exist_ok=True,parents=True)
    evidence=inspect(url,username='standard_user',password='secret_sauce')
    (output/'dom_evidence.json').write_text(json.dumps(evidence,indent=2),encoding='utf8')
    prompt=("Create a QA plan based only on the requirements and observed DOM. "
        "Return JSON object with summary (string), cases (array of 2-3 objects with id,title,steps,expected). "
        "Cover valid login, invalid login and optionally cart interaction. "
        "No invented features. Requirements:\n"+requirements+"\nDOM:\n"+json.dumps(evidence)[:9000])
    result=ask('QA planning agent',prompt,output/'planner',750)
    cases=result.get('cases')
    if not isinstance(cases,list) or not cases:raise ValueError('Planner did not return test cases')
    (output/'test_cases.json').write_text(json.dumps(cases,indent=2),encoding='utf8')
    plan=['# AI-generated SauceDemo test plan','',str(result.get('summary','')),'']
    for case in cases:plan.extend(['## '+str(case.get('id',''))+' — '+str(case.get('title','')),'',str(case.get('steps','')),'','Expected: '+str(case.get('expected','')),''])
    (output/'test_plan.md').write_text('\n'.join(plan),encoding='utf8')
    return cases,evidence
