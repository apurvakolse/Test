import json
from docx import Document
from config import ROOT, ART, URL
from browser_mcp import browser, call
from llm import ask, parse_json

async def run():
    print('1/4 Planner: exploring SauceDemo via real Playwright MCP')
    doc=Document(ROOT/'requirements'/'saucedemo.docx')
    requirements='\n'.join(p.text for p in doc.paragraphs if p.text.strip())
    async with browser() as (session,names):
        snapshot=await call(session,names,'browser_navigate',{'url':URL})
        if 'browser_snapshot' in names:
            snapshot+='\n'+await call(session,names,'browser_snapshot',{})
    (ART/'dom_snapshot.txt').write_text(snapshot,encoding='utf8')
    prompt=f'''Requirements:\n{requirements}\n\nACTUAL MCP accessibility snapshot:\n{snapshot[:9000]}\n\nCreate ONE positive login test case. Respond as JSON object with keys: summary (string), cases (array containing exactly one object with id, title, steps (array of strings), expected (string)). Use only elements supported by snapshot and requirements. No code.'''
    raw=ask('planner','You are a QA test planner. Output valid compact JSON only.',prompt,json_mode=True,tokens=450)
    plan=parse_json(raw)
    if not isinstance(plan.get('cases'),list) or len(plan['cases'])!=1: raise ValueError('Planner did not return one test case')
    (ART/'test_cases.json').write_text(json.dumps(plan,indent=2),encoding='utf8')
    (ART/'test_plan.md').write_text('# AI-generated test plan\n\n'+str(plan.get('summary',''))+'\n\n## Case\n'+json.dumps(plan['cases'][0],indent=2),encoding='utf8')
    print('  Saved artifacts/test_plan.md and test_cases.json')
    return plan,snapshot
