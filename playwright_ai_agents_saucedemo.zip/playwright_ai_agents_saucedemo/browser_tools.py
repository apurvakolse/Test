"""Read-only text DOM discovery on a public demo site."""
import json
from playwright.sync_api import sync_playwright

def inspect(url, username=None, password=None):
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True)
        try:
            page=browser.new_page(viewport={"width":1280,"height":800})
            page.goto(url,wait_until="domcontentloaded",timeout=45000)
            page.locator("body").wait_for(timeout=20000)
            def snapshot():
                return page.evaluate("""() => ({url:location.href,title:document.title,
                  text:document.body.innerText.slice(0,3000),
                  controls:[...document.querySelectorAll('input,button,a,select,[role=button]')].slice(0,65).map(e=>({tag:e.tagName,role:e.getAttribute('role'),id:e.id,name:e.getAttribute('name'),type:e.getAttribute('type'),placeholder:e.getAttribute('placeholder'),text:(e.innerText||'').trim().slice(0,70),dataTest:e.getAttribute('data-test'),ariaLabel:e.getAttribute('aria-label')}))})""")
            before=snapshot()
            after=None
            if username is not None and password is not None:
                # Browser-tool bootstrap to inspect post-login DOM; not test code.
                page.locator('input[data-test="username"]').fill(username)
                page.locator('input[data-test="password"]').fill(password)
                page.locator('input[data-test="login-button"]').click()
                page.wait_for_timeout(800)
                after=snapshot()
            return {'login':before,'after_login':after}
        finally:browser.close()
