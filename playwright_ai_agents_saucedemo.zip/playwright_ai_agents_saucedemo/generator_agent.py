from pathlib import Path
from ollama_client import ask
import json,ast

def run(cases,evidence,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    prompt=("Generate one complete Python pytest module with Playwright synchronous page fixture from pytest-playwright. "
      "Use https://www.saucedemo.com/ . Include valid login and invalid login tests. "
      "Use only DOM-supported selectors, prefer data-test selectors. "
      "Each test must navigate to site and be independent. "
      "For valid login use standard_user / secret_sauce, assert inventory page or inventory products. "
      "For invalid login use invalid_user / invalid_password, assert visible login error. "
      "No external packages besides pytest/playwright. Return JSON object with code containing entire Python source. "
      "Cases: "+json.dumps(cases)+" DOM: "+json.dumps(evidence)[:9000])
    result=ask('Playwright Python test generation agent',prompt,out/'generator',1800)
    code=result.get('code')
    if not isinstance(code,str) or not code.strip():raise ValueError('Generator returned no source')
    ast.parse(code)
    target=out/'test_saucedemo.py';target.write_text(code,encoding='utf8')
    return target
