import json
from pathlib import Path
from ollama_client import ask
from browser_tools import inspect

def run(base_url, requirements, out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    evidence=inspect(base_url+'?version=v1')
    (out/'dom_v1.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
    result=ask('You are a QA test planning agent.',f'Requirements:\n{requirements}\nBrowser DOM evidence:\n{json.dumps(evidence)}\nReturn JSON with keys summary (string) and cases (array of objects each with id, title, steps, expected). Include valid and invalid login tests. Base steps on actual DOM evidence.',out/'planner',900)
    cases=result.get('cases')
    if not isinstance(cases,list) or not cases:raise ValueError('Planner returned no cases')
    (out/'test_cases.json').write_text(json.dumps(cases,indent=2),encoding='utf-8')
    lines=['# AI-generated test plan','',result.get('summary',''),'']
    for c in cases:lines+=['## '+str(c.get('id',''))+' — '+str(c.get('title','')),'','Steps: '+str(c.get('steps','')),'','Expected: '+str(c.get('expected','')),'']
    (out/'test_plan.md').write_text('\n'.join(lines),encoding='utf-8')
    return cases,evidence
