# CSV-driven OHIF DICOM Visual Agents Demo

## Run (Windows VS Code)

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m playwright install chromium
python run_demo.py
```

Edit **`test_cases.csv`** to add, enable, disable, or change test cases. No Python changes required for supported actions. `enabled` is Y/N; `action` is `capture_baseline` or `draw_measurement`; `baseline_mode` is `create` or `reuse`. A `reuse` row must follow a row that creates its `baseline_id`. Coordinates are normalized fractions (0.05–0.95) of the detected DICOM canvas, not millimeters. `expected_status` is the demonstration expectation; the actual PASS/FAIL is always determined by image comparison, never forced.

Default cases: TC01 captures the unmodified viewer baseline and compares it to its copy. TC02 draws a real length annotation for a new baseline, reloads the viewer, redraws the same measurement, and compares. TC03 reloads and draws a different-length measurement, comparing against TC02's baseline. All screenshots and the report are in `results/<timestamp>/`.

Agent 1 calls Ollama to review the CSV scenarios against DOM evidence. **The CSV controls which tests execute**; the model cannot invent executable actions. Agent 2 uses NumPy/Pillow for the pass/fail pixel threshold and calls Ollama to interpret the metrics; llama3.1 is text-only and cannot view images. Agent 3 calls Ollama to summarize results. All Ollama calls save audit files; if they fail, the report records the failure. The browser runs headed.

**Limitations:** Baselines are created during the same run, not approved long-lived goldens. Screenshot comparison may be sensitive to rendering and may miss a small line difference if whole-screen threshold is too generous. OHIF tool labels may change; a missing Length tool causes an explicit failure and writes `measurement_tool_debug.json`. This has been syntax-tested but not run against the live OHIF Viewer. If system volume unexpectedly decreases, stop the task and investigate before continuing.
