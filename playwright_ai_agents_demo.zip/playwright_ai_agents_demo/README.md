# Python + Ollama + Playwright: Planner / Generator / Healer

Text-only AI agent demonstration modeled on the three-agent README reference.

| Agent | Purpose |
|---|---|
| `planner_agent.py` | Reads DOCX requirements, explores live DOM using Python Playwright, asks Ollama for Markdown plan and JSON test cases |
| `generator_agent.py` | Asks Ollama to write standalone Python Playwright pytest test module into `generated-tests/` |
| `healer_agent.py` | Reads failure logs and changed DOM, asks Ollama to fix locators, writes separate file to `healed-tests/` |

This Python implementation uses direct Playwright browser tools rather than the TypeScript Playwright MCP server in the reference screenshot. The agent roles are the same, but this is **not** an exact reproduction of that repository. No screenshot comparison is used.

## Setup (PowerShell)

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m playwright install chromium
$env:OLLAMA_URL="http://10.80.101.55:11434"
$env:OLLAMA_MODEL="llama3.1:latest"
$env:OLLAMA_TIMEOUT="180"
python run_demo.py
```

## Demonstration

1. Edit `requirements/requirements.docx` to change the requirements. Local demo application at `http://127.0.0.1:8765/?version=v1` has button **Sign in**.
2. Planner observes actual DOM and produces `artifacts/test_plan.md`, `artifacts/test_cases.json`.
3. Generator produces `generated-tests/test_login.py`; the generated source must use a text-based button locator to make the healing scenario observable.
4. Pytest executes the generated test on v1. It must pass before continuing.
5. v2 changes button label and ID to **Log in** / `submit-auth`.
6. The original test is run against v2 using a Playwright request routing fixture. It must fail.
7. Healer examines failure and current DOM, produces `healed-tests/test_login.py` without editing original.
8. Re-run the healed test on v2 and inspect `artifacts/summary.json`.

## Important boundaries

- Every AI call is real and logged to `artifacts/*.request.json`, `*.raw.txt`, and `*.json` or `*.error.txt`. No fake AI fallback.
- The remote Ollama server/model may be slow, timeout, or return malformed JSON. When that happens the run stops and records the error. This demo is not guaranteed to pass without iteration.
- The generator is prompted to use a text locator deliberately; it is **not guaranteed** to comply. The demo stops rather than inventing a failure if it doesn't.
- Do not execute arbitrary LLM-generated code against sensitive accounts or systems. This demo uses a local toy application and test credentials only.
- A healer must not change assertions to make tests pass. Review the diff between generated and healed code.
- Test fixtures route v1 URLs to v2 during the breakage phase, preserving the original generated file. No production application code is modified.
