# First Playwright MCP + Ollama four-agent demo

**Purpose:** Demonstrate AI planning, AI test generation, and AI self-healing, and AI reporting, without image comparison or a hardcoded test-case CSV.

## Prerequisites (Windows / VS Code)

- Python 3.11 or 3.12 recommended (Python 3.13+ may work but is not validated here)
- Node.js **20+**, `npx` on PATH
- Network access to SauceDemo, npm and Ollama
- Ollama server with `llama3.1:latest` accessible at the configured address

## Setup

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m playwright install chromium
node --version
npx --version
```

## Run — headed browser (visible)

Generated Playwright tests explicitly use `headless=False`. Playwright MCP uses its normal visible browser mode (no `--headless` flag). Both require a desktop session.

## Run

```powershell
python run_demo.py
```

Demonstrate deliberate locator failure and AI repair:

```powershell
python run_demo.py --heal-demo
```

If a generated test already fails, the healer runs automatically. The `--heal-demo` option injects a stale locator into a **copy** of the generated test (only if it can identify a safe locator to mutate). This is an explicit, artificial failure for demonstration, not a real application defect.

To heal an existing failing test without re-running the planner/generator:

```powershell
python run_demo.py --heal-from generated_tests/test_login.py
```

## Architecture and what to say

1. **Planner** reads `requirements/saucedemo.docx`, starts the **official Playwright MCP server** using a Python MCP client, calls `browser_navigate` and `browser_snapshot`, then asks Ollama for a JSON test plan. **MCP is the tool connection; Ollama is the reasoning model.**
2. **Generator** asks Ollama to turn the test plan and actual browser snapshot into a Python Playwright pytest test, saved to `generated_tests/test_login.py`.
3. **Executor** runs the generated test using pytest. It does **not** use Ollama to determine PASS/FAIL; pytest does that.
4. **Healer** runs only after failure. It uses MCP to inspect the current page, gives the error and original test to Ollama, saves proposed repaired code to `healed_tests/test_login.py`, and reruns it. **The original file is preserved.**

5. **Reporting Agent** asks Ollama to summarize grounded execution evidence, while Python builds `artifacts/report.html` and `artifacts/final_report.json`. Pytest alone determines test PASS/FAIL. The report is generated even if a prior stage fails; AI reporting failures are shown explicitly.

All requests, outputs, snapshots and execution logs are in `artifacts/`.

## File layout

- `run_demo.py` — five-stage orchestrator: Planner, Generator, Executor, Healer (if needed), Reporter
- `browser_mcp.py` — **real** MCP client over stdio, launching `npx -y @playwright/mcp@latest --isolated`
- `llm.py` — direct Ollama HTTP calls with logs; errors stop the demo
- `planner_agent.py`, `generator_agent.py`, `healer_agent.py`, `reporting_agent.py` — four Ollama agents
- `requirements/saucedemo.docx` — editable requirement
- `generated_tests/`, `healed_tests/`, `artifacts/` — generated outputs

## First run troubleshooting

1. If `npx` not found, install Node.js 20+ and restart VS Code.
2. If Playwright MCP cannot launch a browser, run `python -m playwright install chromium` and check the MCP error.
3. If Ollama times out, inspect `artifacts/planner_error.txt`. Test `Invoke-RestMethod http://10.80.101.55:11434/api/tags` in PowerShell and verify the model name.
4. The remote `llama3.1:latest` may be slow or produce invalid code. This demo intentionally stops on failures instead of substituting hardcoded AI results.
5. Generated Python code is **untrusted**. Review `generated_tests/test_login.py` and `healed_tests/test_login.py` before running on any sensitive site. This demo only targets public SauceDemo.
6. Playwright MCP requires Node, even though orchestration and generated tests are Python.

## What this project does NOT claim

- Not tested end-to-end against your remote Ollama server in this environment.
- No guarantee the model generates working tests or repairs them on the first attempt.
- The planner makes one small test plan rather than exploring the entire site autonomously; MCP is used for real browser exploration and the agent decisions are LLM-generated.
- No screenshots or visual verification.

Official docs: https://playwright.dev/python/docs/getting-started-mcp

## Reviewers: what to show (2–4 minutes)

1. Show the DOCX requirement and `browser_mcp.py`: MCP exposes browser tools; Python calls them.
2. Run `python run_demo.py` and show the visible browser, generated plan and test.
3. Run `python run_demo.py --heal-demo` to simulate a locator failure in a copy, then compare original and healed test files.
4. Open `artifacts/report.html`; distinguish deterministic pytest outcomes from Ollama narrative.
5. Explain limitations: text-only LLM, model latency, no claim that AI guarantees correct code or repairs.

**Important:** This is a demo, not a guaranteed pass on every Ollama model. Do not run generated code against production or sensitive applications without review.
