import ast, asyncio
from config import ROOT, ART, URL
from browser_mcp import browser, call
from llm import ask, extract_python

async def run(source,failure):
    print('4/4 Healer: inspecting current page via MCP and proposing repair')
    async with browser() as (session,names):
        snapshot=await call(session,names,'browser_navigate',{'url':URL})
        if 'browser_snapshot' in names: snapshot+='\n'+await call(session,names,'browser_snapshot',{})
    (ART/'healer_dom_snapshot.txt').write_text(snapshot,encoding='utf8')
    prompt=f'''A Python Playwright test failed. Repair ONLY broken selectors or synchronization; preserve test intent, credentials, and assertions. Never change assertions to make tests pass.\nORIGINAL CODE:\n{source.read_text(encoding='utf8')[:9000]}\nFAILURE:\n{failure[-5500:]}\nCURRENT MCP SNAPSHOT:\n{snapshot[:7000]}\nReturn full corrected Python code only.'''
    code=extract_python(ask('healer','You are a cautious QA test repair agent. Return only Python code.',prompt,tokens=950))
    ast.parse(code)
    if 'def test_login' not in code or 'assert' not in code: raise ValueError('Repair removed test or assertion; rejected')
    output=ROOT/'healed_tests'/'test_login.py'
    output.write_text(code,encoding='utf8')
    print('  Saved healed_tests/test_login.py (original preserved)')
    return output
