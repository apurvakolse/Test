"""Run: python run_demo.py [--heal-demo]. Headed browser; four AI agents."""
import argparse
import asyncio
import json
import re
import subprocess
import sys
import time
from pathlib import Path
from config import ROOT, ART
from planner_agent import run as plan
from generator_agent import run as generate
from healer_agent import run as heal
from reporting_agent import run as report


def pytest_run(path, stage):
    cmd = [sys.executable, '-m', 'pytest', '-q', '-s', str(path)]
    start = time.monotonic()
    try:
        proc = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=180)
        code, log = proc.returncode, proc.stdout + '\n' + proc.stderr
    except subprocess.TimeoutExpired as exc:
        code = 124
        log = 'Pytest timeout after 180 seconds\n' + str(exc)
    dest = ART / f'{stage}.log'
    dest.write_text(log, encoding='utf8')
    status = 'PASS' if code == 0 else 'FAIL'
    print(f'  {stage}: {status}; see artifacts/{stage}.log')
    return code, log, {'stage':stage, 'status':status, 'detail':f'pytest exit code {code}', 'file':str(dest.relative_to(ROOT)), 'duration_seconds':round(time.monotonic()-start,1)}


def stale_copy(path):
    original = path.read_text(encoding='utf8')
    patterns = [r'page\.locator\([\'\"]#login-button[\'\"]\)',
                r'page\.get_by_role\(\s*[\'\"]button[\'\"]\s*,\s*name\s*=\s*[\'\"][^\'\"]+[\'\"]\s*\)',
                r'page\.locator\([\'\"]\[data-test=[^\'\"]+[\'\"]\)']
    for pattern in patterns:
        new, count = re.subn(pattern, 'page.locator("#intentionally-stale-login-button")', original, count=1)
        if count:
            dest = ART / 'stale_test_login.py'
            dest.write_text(new, encoding='utf8')
            return dest
    raise RuntimeError('No supported login locator found to simulate a stale locator. Use --heal-from PATH instead.')


async def main():
    parser = argparse.ArgumentParser(description='Four-agent Playwright MCP + Ollama demo')
    parser.add_argument('--heal-demo', action='store_true', help='Simulate a stale locator in a copy')
    parser.add_argument('--heal-from', type=Path, help='Heal an existing failing test')
    args = parser.parse_args()
    events = []
    status = 'INCOMPLETE'
    error = None
    try:
        if args.heal_from:
            source = args.heal_from.resolve()
            if not source.is_file():
                raise FileNotFoundError(source)
            code, log, ev = pytest_run(source, 'failed_run')
            events.append(ev)
            if code == 0:
                status = 'PASS'
                events.append({'stage':'Healer', 'status':'SKIPPED', 'detail':'Test passed; no repair necessary'})
                return
        else:
            print('1/5 Planner: requirements + MCP exploration + Ollama')
            plan_data, snapshot = await plan()
            events.append({'stage':'Planner Agent', 'status':'PASS', 'detail':'Ollama generated a JSON test plan using MCP evidence', 'file':'artifacts/test_cases.json'})
            print('2/5 Generator: create Playwright test with Ollama')
            generated = generate(plan_data, snapshot)
            events.append({'stage':'Generator Agent', 'status':'PASS', 'detail':'Python Playwright test generated and syntax checked', 'file':str(generated.relative_to(ROOT))})
            print('3/5 Executor: headed Playwright pytest')
            code, log, ev = pytest_run(generated, 'original_run')
            events.append(ev)
            if args.heal_demo:
                source = stale_copy(generated)
                events.append({'stage':'Fault injection', 'status':'SIMULATED', 'detail':'Introduced stale locator in a COPY; original test preserved', 'file':str(source.relative_to(ROOT))})
                code, log, ev = pytest_run(source, 'failed_run')
                events.append(ev)
                if code == 0:
                    raise RuntimeError('Injected stale locator did not fail; no evidence for a repair demo')
            else:
                source = generated
        if code == 0:
            status = 'PASS'
            events.append({'stage':'Healer Agent', 'status':'SKIPPED', 'detail':'No failing test to repair'})
            return
        print('4/5 Healer: investigate failed test via MCP + Ollama')
        healed = await heal(source, log)
        events.append({'stage':'Healer Agent', 'status':'PASS', 'detail':'Generated candidate repair; requires pytest validation', 'file':str(healed.relative_to(ROOT))})
        healed_code, healed_log, ev = pytest_run(healed, 'healed_run')
        events.append(ev)
        if healed_code:
            status = 'FAIL'
            raise RuntimeError('Healed test still fails; see artifacts/healed_run.log')
        status = 'PASS'
    except Exception as exc:
        status = 'FAIL'
        error = str(exc)
        print('DEMO ERROR:', error)
    finally:
        if not events:
            events.append({'stage':'Startup', 'status':'FAIL', 'detail':error or 'No stages executed'})
        try:
            report(events, status, error)
        except Exception as exc:
            print('REPORTING ERROR:', exc)
            status = 'FAIL'
        print('REPORT: artifacts/report.html')
    if status != 'PASS':
        raise SystemExit(1)
    print('DEMO COMPLETE: review artifacts/report.html')


if __name__ == '__main__':
    asyncio.run(main())
