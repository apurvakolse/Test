"""Small, observable Ollama JSON client; no pretend AI fallback."""
import json, os, time, urllib.request
from pathlib import Path

URL=os.getenv('OLLAMA_URL','http://10.80.101.55:11434').rstrip('/')
MODEL=os.getenv('OLLAMA_MODEL','llama3.1:latest')
TIMEOUT=int(os.getenv('OLLAMA_TIMEOUT','180'))

def ask(role, prompt, output, max_tokens=650):
    output=Path(output); output.parent.mkdir(parents=True,exist_ok=True)
    payload={'model':MODEL,'stream':False,'format':'json','messages':[{'role':'system','content':role+' Return a valid JSON object only. No markdown.'},{'role':'user','content':prompt}], 'options':{'temperature':0,'num_predict':max_tokens}}
    output.with_suffix('.request.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    started=time.monotonic()
    try:
        req=urllib.request.Request(URL+'/api/chat',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=TIMEOUT) as r: raw=json.loads(r.read().decode())
        content=raw['message']['content']
        output.with_suffix('.raw.txt').write_text(content,encoding='utf-8')
        result=json.loads(content)
        if not isinstance(result,dict): raise ValueError('LLM did not return a JSON object')
        output.with_suffix('.json').write_text(json.dumps({'seconds':round(time.monotonic()-started,2),'result':result},indent=2),encoding='utf-8')
        return result
    except Exception as exc:
        output.with_suffix('.error.txt').write_text(f'{type(exc).__name__}: {exc}\nElapsed: {time.monotonic()-started:.1f}s',encoding='utf-8')
        raise RuntimeError(f'Ollama failed at {output.name}: {exc}') from exc
