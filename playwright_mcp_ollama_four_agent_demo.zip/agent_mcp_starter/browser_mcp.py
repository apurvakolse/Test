"""Actual Python MCP client connected to official Playwright MCP over stdio."""
import asyncio, json, os, shutil
from contextlib import asynccontextmanager
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from config import ART

@asynccontextmanager
async def browser():
    command=shutil.which('npx.cmd' if os.name=='nt' else 'npx') or 'npx'
    params=StdioServerParameters(command=command,args=['-y','@playwright/mcp@latest','--isolated'],env=None)
    async with stdio_client(params) as (read,write):
        async with ClientSession(read,write) as session:
            await session.initialize()
            tools=await session.list_tools()
            names=[t.name for t in tools.tools]
            (ART/'mcp_tools.json').write_text(json.dumps(names,indent=2),encoding='utf8')
            print('  MCP tools available:', ', '.join(n for n in names if n in ('browser_navigate','browser_snapshot','browser_click','browser_type')))
            yield session,names

async def call(session,names,name,arguments):
    if name not in names: raise RuntimeError(f'MCP tool unavailable: {name}')
    result=await session.call_tool(name,arguments)
    text='\n'.join(getattr(x,'text','') for x in result.content)
    if result.isError: raise RuntimeError(f'MCP {name}: {text[:700]}')
    return text
