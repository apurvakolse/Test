import os
from pathlib import Path
ROOT = Path(__file__).parent
URL = 'https://www.saucedemo.com/'
OLLAMA_URL = os.getenv('OLLAMA_URL', 'http://10.80.101.55:11434').rstrip('/')
MODEL = os.getenv('OLLAMA_MODEL', 'llama3.1:latest')
TIMEOUT = int(os.getenv('OLLAMA_TIMEOUT', '180'))
ART = ROOT / 'artifacts'
ART.mkdir(exist_ok=True)
