import json
import time
from datetime import datetime
from pathlib import Path
from PIL import Image, ImageDraw
from playwright.sync_api import sync_playwright
from agents import TestGenerationAgent, VisualVerificationAgent, ReportingAgent

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / 'config.json').read_text(encoding='utf-8'))
OUTPUT = ROOT / 'results' / datetime.now().strftime('%Y%m%d_%H%M%S')
OUTPUT.mkdir(parents=True, exist_ok=True)

def log(message):
    print(f'[{datetime.now():%H:%M:%S}] {message}', flush=True)

def dismiss_tutorial(page):
    try:
        locator = page.get_by_text('Skip all', exact=True)
        if locator.count() and locator.first.is_visible():
            locator.first.click(timeout=3000)
    except Exception:
        pass
    try:
        locator = page.get_by_text('Confirm and hide', exact=True)
        if locator.count() and locator.first.is_visible():
            locator.first.click(timeout=3000)
    except Exception:
        pass

def discover(page):
    return page.evaluate('''() => {
      const canvas = [...document.querySelectorAll('canvas')].map((e,i) => {
        const r=e.getBoundingClientRect();return {index:i,x:Math.round(r.x),y:Math.round(r.y),width:Math.round(r.width),height:Math.round(r.height),visible:r.width>100&&r.height>100};
      });
      const controls=[...document.querySelectorAll('button,[role="button"],[title],[aria-label]')].slice(0,120).map((e)=>{
        const r=e.getBoundingClientRect();return {tag:e.tagName,text:(e.innerText||'').trim().slice(0,60),title:e.getAttribute('title'),label:e.getAttribute('aria-label'),x:Math.round(r.x),y:Math.round(r.y)};
      });
      return {url:location.href,resolution:{width:innerWidth,height:innerHeight,devicePixelRatio:devicePixelRatio},canvas,controls};
    }''')

def main():
    results = []
    plan = {'source': 'not generated', 'tests': []}
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page(viewport=CONFIG['viewport'], device_scale_factor=1)
        try:
            log('Opening OHIF study list')
            page.goto(CONFIG['url'], wait_until='domcontentloaded', timeout=60000)
            study = page.get_by_text(CONFIG['study'], exact=True)
            study.first.wait_for(state='visible', timeout=60000)
            count = study.count()
            log(f'Found {count} matching study labels')
            if count != 1:
                raise RuntimeError(f'Expected one study label; found {count}. Verify the study list.')
            study.dblclick(timeout=15000)
            log('Study selected; waiting for image canvas')
            page.wait_for_url('**/viewer?**', timeout=60000)
            deadline = time.monotonic() + 75
            while time.monotonic() < deadline:
                dismiss_tutorial(page)
                evidence = discover(page)
                if any(c['visible'] for c in evidence['canvas']):
                    break
                page.wait_for_timeout(1500)
            else:
                raise RuntimeError('No visible DICOM canvas was detected')
            # Allow asynchronous DICOM pixel rendering to settle before capturing baseline.
            page.wait_for_timeout(4000)
            dismiss_tutorial(page)
            evidence = discover(page)
            (OUTPUT / 'dom_evidence.json').write_text(json.dumps(evidence, indent=2), encoding='utf-8')
            log('Agent 1: generating validated test definitions')
            plan = TestGenerationAgent().generate(evidence, CONFIG, OUTPUT)
            (OUTPUT / 'generated_tests.json').write_text(json.dumps(plan, indent=2), encoding='utf-8')
            log(f'Plan source: {plan["source"]}')
            # Capture full viewport at fixed browser dimensions. A true approved golden image
            # should be captured and reviewed separately for production regression testing.
            baseline = OUTPUT / 'baseline.png'
            page.screenshot(path=str(baseline), animations='disabled')
            verifier = VisualVerificationAgent()
            for test in plan['tests']:
                tid = test['id']
                action = test['action']
                log(f'Executing {tid}: {test["name"]}')
                actual = OUTPUT / f'{tid}_actual.png'
                diff = OUTPUT / f'{tid}_difference.png'
                if action == 'baseline':
                    # Same capture is the smoke-test baseline: checks rendering, not independent visual regression.
                    actual.write_bytes(baseline.read_bytes())
                elif action == 'repeat':
                    page.screenshot(path=str(actual), animations='disabled')
                elif action == 'negative':
                    if not CONFIG.get('demo_intentional_failure', True):
                        page.screenshot(path=str(actual), animations='disabled')
                    else:
                        with Image.open(baseline) as img:
                            altered = img.convert('RGB')
                            d = ImageDraw.Draw(altered)
                            w,h = altered.size
                            d.rectangle((int(w*.45),int(h*.40),int(w*.65),int(h*.60)),fill=(245,30,30))
                            altered.save(actual)
                else:
                    raise ValueError(f'Unsupported generated action: {action}')
                check = verifier.compare(baseline, actual, diff, CONFIG['difference_threshold'])
                analysis = verifier.analyze_with_ollama(check, test, CONFIG, OUTPUT)
                results.append({'ai_analysis': analysis, 'id': tid, 'name': test['name'], 'status': check['status'],
                                'reason': check['reason'], 'expected': baseline.name,
                                'actual': actual.name, 'diff': diff.name})
                log(f'{tid} -> {check["status"]}: {check["reason"]}')
        except Exception as exc:
            log(f'Execution error: {exc}')
            results.append({'id':'SETUP', 'name':'Open study and discover viewport', 'status':'FAIL', 'reason':str(exc)})
            try:
                page.screenshot(path=str(OUTPUT / 'setup_error.png'))
            except Exception:
                pass
        finally:
            browser.close()
    reporter = ReportingAgent()
    ai_report = reporter.analyze_with_ollama(results, plan, CONFIG, OUTPUT)
    summary = reporter.write(results, plan, OUTPUT, ai_report)
    log(f'Report: {OUTPUT / "report.html"}')
    log(f'Summary: {summary}')

if __name__ == '__main__':
    main()
