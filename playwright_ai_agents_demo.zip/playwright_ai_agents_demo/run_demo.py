"""Run: python run_demo.py. Requires Ollama, playwright, pytest, pytest-playwright."""
import os,subprocess,sys,time,json,threading
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from functools import partial
from docx import Document
from planner_agent import run as plan
from generator_agent import run as generate
from healer_agent import run as heal
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'artifacts';OUT.mkdir(exist_ok=True)

def run_pytest(test_file,version,name):
    env=os.environ.copy();env['DEMO_VERSION']=version
    # Generated test points at v1; when testing v2, intercept page.goto via a fixture in conftest.py.
    result=subprocess.run([sys.executable,'-m','pytest','-q','-s','--tb=short',str(test_file),'--json-report',f'--json-report-file={OUT/name}.json'],cwd=ROOT,capture_output=True,text=True,env=env,timeout=120)
    log=result.stdout+'\n'+result.stderr
    (OUT/f'{name}.log').write_text(log,encoding='utf-8')
    print(f'{name}: exit {result.returncode}\n{log[-1800:]}')
    return result.returncode,log

def main():
    handler=partial(SimpleHTTPRequestHandler,directory=str(ROOT/'demo_app'))
    server=ThreadingHTTPServer(('127.0.0.1',8765),handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        print('STEP 1: Planner explores DOM and creates test plan',flush=True)
        requirements='\n'.join(p.text for p in Document(ROOT/'requirements/requirements.docx').paragraphs if p.text.strip())
        cases,evidence=plan('http://127.0.0.1:8765/',requirements,OUT)
        print('STEP 2: Generator creates Python Playwright tests',flush=True)
        test=generate(cases,evidence,ROOT/'generated-tests')
        print('STEP 3: Run tests on v1 (expected pass)',flush=True)
        first,_=run_pytest(test,'v1','v1_results')
        if first:raise RuntimeError('Generated tests failed on original UI. Inspect artifacts/v1_results.log; do not attempt healing before baseline passes.')
        print('STEP 4: Run unchanged tests on v2 (expected locator failure)',flush=True)
        broken,log=run_pytest(test,'v2','v2_before_heal')
        if not broken:raise RuntimeError('v2 tests did not fail. Cannot demonstrate healing; inspect generated selectors.')
        print('STEP 5: Healer reviews failure and changed DOM',flush=True)
        healed=heal(test,log,ROOT/'healed-tests')
        print('STEP 6: Rerun healed tests on v2',flush=True)
        fixed,_=run_pytest(healed,'v2','v2_after_heal')
        summary={'original_passed':first==0,'changed_ui_failed':broken!=0,'healed_passed':fixed==0,'original':str(test),'healed':str(healed)}
        (OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
        print('SUMMARY:',json.dumps(summary,indent=2))
    finally:server.shutdown()

if __name__=='__main__':main()
