from pathlib import Path
from ollama_client import ask
from browser_tools import inspect
import ast,json

def run(original, failed_log, out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    evidence=inspect('https://www.saucedemo.com/',username='standard_user',password='secret_sauce')
    (out/'dom_on_failure.json').write_text(json.dumps(evidence,indent=2),encoding='utf8')
    original=Path(original)
    prompt=("Repair failing Python Playwright pytest source. Fix locator/interaction errors only, "
      "do not change credentials, expected behavior or weaken/remove assertions. "
      "Return JSON with explanation and code (complete corrected module). "
      "Original:\n"+original.read_text(encoding='utf8')[:14000]+"\nFailure:\n"+failed_log[-5000:]+"\nDOM:\n"+json.dumps(evidence)[:9000])
    result=ask('Cautious Playwright self-healing agent',prompt,out/'healer',1900)
    code=result.get('code')
    if not isinstance(code,str) or not code.strip():raise ValueError('Healer returned no source')
    ast.parse(code)
    target=out/'test_saucedemo.py';target.write_text(code,encoding='utf8')
    (out/'explanation.txt').write_text(str(result.get('explanation','')),encoding='utf8')
    return target
