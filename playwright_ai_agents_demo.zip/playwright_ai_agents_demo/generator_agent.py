from pathlib import Path
from ollama_client import ask
import json,ast

def run(cases,evidence,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    prompt=f'Generate ONE complete Python pytest module using playwright.sync_api and pytest. Test the login requirements. Browser is passed as pytest playwright page fixture? NO: use the supplied pytest fixture named page from pytest-playwright. Use URL http://127.0.0.1:8765/?version=v1 in page.goto. Use stable selectors from DOM. Include at least one test for successful login and one for invalid credentials. IMPORTANT: for demo self-healing, select the submit button by exact visible text Sign in (page.get_by_role("button",name="Sign in")) so the changed label in v2 causes a locator failure. Assertions must check actual status text. Return JSON with key code containing entire Python source. Cases: {json.dumps(cases)} DOM: {json.dumps(evidence)}'
    result=ask('You generate executable Python Playwright pytest tests. Do not invent selectors.',prompt,out/'generator',1600)
    code=result.get('code','')
    if not isinstance(code,str) or not code.strip():raise ValueError('Generator returned no code')
    ast.parse(code)
    (out/'test_login.py').write_text(code,encoding='utf-8')
    return out/'test_login.py'
