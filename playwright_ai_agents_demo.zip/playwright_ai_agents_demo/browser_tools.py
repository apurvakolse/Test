"""Text-only Playwright browser inspection. No screenshot comparison."""
from playwright.sync_api import sync_playwright

def inspect(url):
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True)
        try:
            page=browser.new_page();page.goto(url,wait_until='domcontentloaded')
            return {'url':url,'title':page.title(),'dom':page.locator('body').evaluate('e => e.outerHTML')[:9000], 'visible_text':page.locator('body').inner_text()[:3000]}
        finally:browser.close()
