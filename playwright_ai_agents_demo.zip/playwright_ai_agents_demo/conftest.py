"""Switch UI version for the demo without editing generated source."""
import os
import pytest

@pytest.fixture
def page(browser):
    context=browser.new_context()
    page=context.new_page()
    version=os.getenv('DEMO_VERSION','v1')
    if version=='v2':
        def switch_version(route):
            url=route.request.url.replace('version=v1','version=v2')
            route.continue_(url=url)
        page.route('**/*version=v1*',switch_version)
    yield page
    context.close()
